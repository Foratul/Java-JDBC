/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gestion;
import DAO.TareaDAO;
import Bean.Tarea;
import Bean.Usuario;
import java.util.*;

/**
 *
 * @author aula2m
 */
public class GestionTarea {
    TareaDAO dao;
    
    public GestionTarea(){
    
    dao = new TareaDAO();
    }
    
    
   public boolean guardarTarea(Tarea t){
    
        return dao.guardarTarea(t);
    
    }
   
   
   public ArrayList<Tarea> recuperTareasDeUsuario(Usuario user)
   {
       
       return dao.recuperTareasDeUsuario(user);
   }
    
     public boolean marcarTareaTerminada(int id){
         
         Tarea t = dao.IdtoTarea(id);
         t.setEstado(!t.getEstado());
         return dao.modificarTarea(t);
         
         
     }
     
     
     
     
     public boolean eliminarTarea(int id, Usuario user){
         Tarea t = dao.IdtoTarea(id);
         return dao.eliminarTarea(t, user);
     }
                           
    public     boolean eliminarTareasDeUsuario(Usuario user){
             
             return dao.eliminarTareasDeUsuario(user);
         }
         
         	
	public void salir(){
		dao.desconectar();
        }
         
   
}
