/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Gestion;

/**
 *
 * @author aula2m
 */

 import Bean.Usuario;
 import DAO.UsuarioDAO;
 import java.util.*;
//import javax.swing.JOptionPane;
 
public class GestionUsuario {
    
   
        UsuarioDAO dao;

public GestionUsuario (){

dao = new UsuarioDAO();

}

        
        public boolean registrar (Usuario user){
       
        return dao.guardarUsuario(user);
        }
        
        
        public Usuario login (Usuario user){
        
        Usuario u = dao.recuperarUsuario(user.getNombre());
        if (u == null) return null;
        else if ( u.getNombre().equals(user.getNombre()) && ( u.getPass().equals(user.getPass()) ))  return u;           
        else return null;
        
}


           public ArrayList <Usuario> mostrarUsuarios(){
           
               return dao.mostrarUsuarios();
           
                      }
           
           public Usuario recuperarUsuario(String nombre) {
		return dao.recuperarUsuario(nombre);
		}

}
