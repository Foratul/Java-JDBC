/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

/**
 *
 * @author aula2m
 */

import java.sql.*;
import java.util.*;
import Bean.*;



public class TareaDAO {
    
    Connection conexion;
    
 public TareaDAO (){
    try{
    Class.forName("com.mysql.jdbc.Driver");                 
    conexion = DriverManager.getConnection("jdbc:mysql://localhost/tareasusuarios","root",""); 
    
    
    }
    
        
        catch(ClassNotFoundException cnfe){
System.out.println("Driver JBDC no encontrado");
cnfe.printStackTrace();               
}
        catch(SQLException sqle){
System.out.println("Error al conectarse a la BD");
sqle.printStackTrace();
}
        catch(Exception e){
System.out.println("Error general");
e.printStackTrace();} 
    
    }
 
 
 public boolean guardarTarea(Tarea t){
 
  try {
    PreparedStatement sentencia2 = conexion.prepareStatement("INSERT into tareas values(null, ?,false,?)");
        sentencia2.setString(1, t.getTitulo());//1 Especifica el primer parámetro
        sentencia2.setString(2, (t.getUsuario()).getNombre());
        int cambios =sentencia2.executeUpdate();
    return true;
    }
           catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD");
           sqle.printStackTrace();}
           return false; 

  
 }
 
  public boolean modificarTarea (Tarea t){
      try {
          
    Statement sentencia2 = conexion.createStatement();
          System.out.println(t.getEstado());
   String orden = "UPDATE tareas SET estado = " +  t.getEstado() + " where id = " + t.getId();
          System.out.println(orden);
   int cambios = sentencia2.executeUpdate(orden);
   return true;
    }
           catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD");
           sqle.printStackTrace();
           return false; 
  }
 
}

 public boolean eliminarTarea (Tarea t, Usuario user){
      try {
    Statement sentencia2 = conexion.createStatement();
  String orden = "DELETE from tareas where id = '" + t.getId() + "' AND nombreUsuario = '" + user.getNombre()+"'";
  // orden = "DELETE from tareas where id = '17'" + " AND nombreUsuario = 'Mickey'";
          System.out.println(orden);
   int cambios=sentencia2.executeUpdate(orden);

return true;
    }
           catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD");
           sqle.printStackTrace();
           return false; 
  }
 }
  public boolean eliminarTareasDeUsuario (Usuario user){
      try {
    Statement sentencia2 = conexion.createStatement();
   String orden = "DELETE from tareas where nombreUsuario= '" + user.getNombre() +"'";
   sentencia2.executeUpdate(orden);

return true;
    }
           catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD");
           sqle.printStackTrace();
           return false; 
  }
 }
  
  public void desconectar(){
		try{
                    conexion.close();
		}catch (Exception e) {
			System.out.println("No se puede cerrar la conexion");
			e.printStackTrace();
		}
	}
 
 
    public ArrayList<Tarea> recuperTareasDeUsuario(Usuario user)
    {
      try {
    Statement sentencia2 = conexion.createStatement();
   String orden = "SELECT * from tareas where nombreUsuario='" + user.getNombre()+"' order by estado ASC, id ASC";
   ResultSet tablaTareas =sentencia2.executeQuery(orden);
   ArrayList<Tarea> tareas= new ArrayList();
    while(tablaTareas.next())
    {
   int id= tablaTareas.getInt("id");
   String titulo = tablaTareas.getString("titulo");
   boolean estado = tablaTareas.getBoolean("estado");

   Tarea tarea = new Tarea(titulo,estado, user);
				tareas.add(tarea);
    tarea.setId(id);
		
    }
         return tareas;

      }
           catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD");
           sqle.printStackTrace();
           return null; 
  }
    }
    
     public Tarea IdtoTarea(int id){
		try {
			Statement sentencia= conexion.createStatement();
			ResultSet tablaTareas =sentencia.executeQuery("select * from tareas where id="+id);
			tablaTareas.next();
			//int idt  = tablaTareas.getInt("id");
                        String  titulo  = tablaTareas.getString("titulo");
			boolean estado = tablaTareas.getBoolean("estado");
                        String usrname = tablaTareas.getString("nombreUsuario");
			Tarea tarea = new Tarea(titulo,estado,null);
                        tarea.setId(id);
			return tarea;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
	}
}

    


