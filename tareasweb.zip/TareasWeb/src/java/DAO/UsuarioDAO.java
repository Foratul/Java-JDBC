/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Gestion.*;
import Bean.*;
import java.sql.*;
import java.util.ArrayList;


/**
 *
 * @author aula2m
 */
public class UsuarioDAO {
    
    Connection conexion;

 
    
    public UsuarioDAO(){
                     
    try{
    Class.forName("com.mysql.jdbc.Driver");                 
    conexion = DriverManager.getConnection("jdbc:mysql://localhost/tareasusuarios","root",""); 
    
    
    }
    
        
        catch(ClassNotFoundException cnfe){
System.out.println("Driver JBDC no encontrado");
cnfe.printStackTrace();               
}
        catch(SQLException sqle){
System.out.println("Error al conectarse a la BD UsuarioDAO");
sqle.printStackTrace();
}
        catch(Exception e){
System.out.println("Error general");
e.printStackTrace();} 
}
    
   public boolean guardarUsuario(Usuario user){
   
      try {
       PreparedStatement sentencia2 = conexion.prepareStatement("INSERT into usuarios values(?, ?);");
       sentencia2.setString(1, user.getNombre());//1 Especifica el primer parámetro
       sentencia2.setObject(2, user.getPass());
       int i=sentencia2.executeUpdate();
    return true;
   }
        
       
          catch (SQLException sqle){
          System.out.println("Error al conectarse a la BD guardar USUARIO");
           sqle.printStackTrace();
           
       return false; }
 
 }
   public Usuario recuperarUsuario(String nombre){
              try {

           Statement sentencia= conexion.createStatement();
           ResultSet tablaTareas =sentencia.executeQuery("select * from usuarios where nombre='"+nombre+"';");
           if (tablaTareas.next()){
           String nombreusr = tablaTareas.getString(1);
	   String password  = tablaTareas.getString(2);
       

           Usuario user = new Usuario (nombreusr, password);
           TareaDAO dao = new TareaDAO();
           user.setTareas(dao.recuperTareasDeUsuario(user));
           return user;}
           else return null;
   
   
              }
              
              catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD al RECUPERAR USUARIO");
           sqle.printStackTrace();
           
           return null; }
   }
   
   public  boolean modificarUsuario(Usuario user){
              try {
        Statement sentencia= conexion.createStatement();
        sentencia.executeUpdate("update usuarios SET pass="+user.getPass()+" where nombre="+user.getNombre());
           return true;
   
   
              }
              
              catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD modificar USUARIO");
           sqle.printStackTrace();
           return false;}
   
   
   }
   
   
    public  boolean eliminarUsuario(Usuario user){
              try {
        Statement sentencia= conexion.createStatement();
        sentencia.executeUpdate("delete from usuarios where nombre="+user.getNombre());
           return true;
     
              }
              
              catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD elminiar USUARIO");
           sqle.printStackTrace();
           return false;}
      
   }
    
    public ArrayList mostrarUsuarios(){
      try {
    Statement sentencia2 = conexion.createStatement();
   String orden = "SELECT * from usuarios";
   ResultSet tablaUsuarios  = sentencia2.executeQuery(orden);
   ArrayList<Usuario> usuarios= new ArrayList<Usuario>();
    while(tablaUsuarios.next())
    {
   String nombre = tablaUsuarios.getString("Nombre");
   String pass = tablaUsuarios.getString("pass");

   Usuario user = new Usuario (nombre, pass);
   usuarios.add(user);
		
    }
         return usuarios;

      }
           catch (SQLException sqle){
           System.out.println("Error al conectarse a la BD");
           sqle.printStackTrace();
           return null; 
  }
    }
}
