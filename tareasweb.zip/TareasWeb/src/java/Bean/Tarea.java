/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

/**
 *
 * @author aula2m
 */
public class Tarea {
 
    private String titulo;
    private Usuario usuario;
    private int id;
    private boolean estado;
    
    public Tarea(String titulo, boolean estado, Usuario usuario){
    this.id=0;
    this.titulo=titulo;
    this.estado=estado;
    this.usuario=usuario; 
    
    
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean getEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
    
    
    public Tarea(){};
    
}

