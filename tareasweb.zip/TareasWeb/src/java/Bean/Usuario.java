/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;
import java.util.*;
/**
 *
 * @author aula2m
 */
public class Usuario {
    
    private String nombre, pass;
    ArrayList<Tarea> tareas;
    
   public Usuario() {
      this.tareas = new ArrayList<Tarea>();
        }


    public Usuario(String nombre, String pass) {
        this.nombre = nombre;
        this.pass = pass;
        this.tareas = new ArrayList<Tarea>();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public ArrayList<Tarea> getTareas() {
        return tareas;
    }

    public void setTareas(ArrayList<Tarea> tareas) {
        this.tareas = tareas;
    }
    
    public Tarea getTarea(int id){
    
        ArrayList<Tarea> tareas = this.tareas;
        for (Tarea tarea : tareas) {
            if (tarea.getId()==id) return tarea;
        }
          
    return null;
    }
    
    public boolean addTarea(Tarea t){
    
        return this.tareas.add(t);        
        
    }
    
    
    
}
